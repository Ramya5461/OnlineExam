import { ExamUser } from "../login/ExamUser";
import { Exam } from "./Exam";
import { ExamLevel } from "./ExamLevel";

export class ExamResult
{
    resultId!: number;
    exam!: Exam;
    examUser!: ExamUser;
    examLevel!: ExamLevel;
    crctAns!: number;
    incrctAns!: number;
    marks!: number; 
    percentage!: DoubleRange;
    status!: string;

}