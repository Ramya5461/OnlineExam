import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ExamUser } from './ExamUser';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private regServ: RegisterService,private router:Router) { }
  examuser: ExamUser = new ExamUser();
  isLoggedIn: boolean=false;
  loginstr!: any;
  ngOnInit(): void {
   
      this.loginstr=sessionStorage.getItem("loginInfo");
      this.isLoggedIn=JSON.parse(this.loginstr);
  }
  addUser(examuser: ExamUser){
    //alert(examuser.username);
    //alert(examuser.email);
    if(examuser.username==null || examuser.email==null || examuser.password==null){
      alert("cannot be null");
    }
    else{
    this.regServ.addUserService(examuser).subscribe((data)=>
    {
     
      if(data!=null){
        alert(this.examuser);
        console.log(data);
        alert(data);
       // alert("Registration success");
        this.router.navigate(["login"]);
      }},
      (err)=>{
        alert("some thing went wrong");
       console.log(err);
     }
    
    )
  }
}
}
