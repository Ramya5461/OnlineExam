export class UserOptionDto
{
    userId: number | undefined;
     qsNo : number | undefined;
    usOption : String |undefined;
}