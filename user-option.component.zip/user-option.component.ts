import { Component, OnInit } from '@angular/core';
import { UserOptionService } from './user-option.service';
import { UserOptionDto } from './UserOptionDto';

@Component({
  selector: 'app-user-option',
  templateUrl: './user-option.component.html',
  styleUrls: ['./user-option.component.css']
})
export class UserOptionComponent implements OnInit {
  constructor(private ccs:UserOptionService) { }
  //userOption: UserOptionComponent = new UserOptionComponent();
  userOptionDto:UserOptionDto = new UserOptionDto();
  
  ngOnInit(): void {
  }
  userId=0;
  qsNo=0;
  tempUser:Array<any> |undefined;
  updateOrAddOption(userOptionDto:UserOptionDto){
    this.ccs.updateOrAddOptionService(userOptionDto).subscribe((data)=>{
      if(data!=null){
        console.log(data);
        alert("Updating or adding is successful");
      }},
      (err)=>{
        alert("some thing went wrong");
       console.log(err);
     }
    
    )
}
}