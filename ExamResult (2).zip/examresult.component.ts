import { Component, OnInit } from '@angular/core';
import { ExamResultService } from '../exam-result/exam-result.service';
import { ExamResult } from './ExamResult';

@Component({
  selector: 'app-examresult',
  templateUrl: './examresult.component.html',
  styleUrls: ['./examresult.component.css']
})
export class ExamresultComponent implements OnInit {
  constructor(private ccs : ExamResultService) { }

  ngOnInit(): void {
  }
  UserId=0;
  tempResult: ExamResult= new ExamResult();
  getResultsByUserId(UserId: number){
    this.ccs.getResultsByUserId(UserId).subscribe((data)=>{
    if(data!=null){
        this.tempResult=data;
      
        sessionStorage.setItem("resultDetails",JSON.stringify(data)); // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }})
  }
/*
  tempResult1: ExamResult= new ExamResult();
  getAllResults(){
    this.ccs.getAllResults().subscribe((data)=>{
    if(data!=null){
        this.tempResult1=data;
        sessionStorage.setItem("resultDetails",JSON.stringify(data)); // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }}
  
    )
  
  }
  /*
  tempResult2: ExamResult= new ExamResult();
  getResultByUserIdExamIdLevelId(UserId,ExamId,LevelId(){
    this.ccs.getResultByUserIdExamIdLevelId().subscribe((data)=>{
    if(data!=null){
        this.tempResult2=data;
        sessionStorage.setItem("resultDetails",JSON.stringify(data)); // storing this on browser session
    }
    else{
        alert("unable to fetch");
    }}*/
  
  }
