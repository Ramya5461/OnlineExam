export class ExamResult
{
userId:number|undefined;
resultId :number |undefined;
attemptedQs :number |undefined;
crctAns : number |undefined;
incrctAns :number |undefined;
marks :number |undefined;
nonAttemptedQs :number|undefined;
percentage :DoubleRange |undefined;
status :string |undefined;
}