import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ExamResult } from '../examresult/ExamResult';

@Injectable({
  providedIn: 'root'
})
export class ExamResultService {

  constructor(private myHttp:HttpClient) { }
    getResultsByUserId(UserId: number):Observable<ExamResult>{
    return this.myHttp.get<ExamResult>("http://localhost:8080/getResultsByUserId/"+UserId)
}
  getAllResults(): Observable<ExamResult> {
  return this.myHttp.get<ExamResult>("http://localhost:8080/getAllResults");
   
}
/*

getAllResults(): Observable<ExamResult> {
  return this.myHttp.get<ExamResult>("http://localhost:8080/getAllResults");
   : Observable<ExamResult> {
  return this.myHttp.get<ExamResult>("http://localhost:8080/getAllResults");
   */


}

