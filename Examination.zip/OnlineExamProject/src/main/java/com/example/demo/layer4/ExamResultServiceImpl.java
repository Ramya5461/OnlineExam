package com.example.demo.layer4;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.ExamResult;
import com.example.demo.layer3.ResultRepository;
import com.example.demo.layer4.exception.ResultNotFoundException;


@Service
public class ExamResultServiceImpl implements ExamResultService {
	@Autowired
	ResultRepository resultRepo;
	
@Override
	public void addResultService(ExamResult result) {
	resultRepo.addResult(result);
	}


@Override
	 public List<ExamResult> getAllResultsService(){
			return resultRepo.getAllResults();
	 }

@Override
	public ExamResult getResultByUserIdExamIdLevelIdService(int myUserId, int myExamId, int myLevelId)throws ResultNotFoundException  {
		System.out.println("Result Service....Some scope of bussiness logic here...");
		ExamResult examResult= resultRepo.getResultByUserIdExamIdLevelId(myUserId,myExamId,myLevelId);
		if(examResult == null) {
			throw new ResultNotFoundException("Result Not Found");
			}
			return examResult;
		} 

@Override
	public List<ExamResult> getResultsByUserIdService(int userId)throws ResultNotFoundException {
			System.out.println("Result Service....Some scope of bussiness logic here...");
			List<ExamResult> examResult= resultRepo.getResultsByUserId(userId);
			if(examResult == null) {
				throw new ResultNotFoundException("Result Not Found");
			}
			return examResult;
		} 

	}
	 
