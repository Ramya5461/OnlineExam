package com.example.demo.layer4;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.UserOption;
import com.example.demo.layer3.UserOptionRepository;
@Service
public class UserOptionServiceImpl implements UserOptionService {
@Autowired
		UserOptionRepository userOptionRepo;
		
@Override
	public void addUserOptionService(UserOption userOption ) {
		userOptionRepo.addUserOption(userOption);
		}
@Override
 public UserOption getUserOptionByUserIdandQuestionNumberService(int userId,int qsNo) {
	 UserOption userOption=userOptionRepo.getUserOptionByUserIdandQuestionNumber(userId,qsNo);
			   return userOption;
		}
	}


/*
	public int CompareUserOptionWithCorrectOption() {
		Question question=new Question();
		UserOption userOption=new UserOption();
		ExamResult examResult=new ExamResult();
		question.getCrctOpt();
		userOption.getUsOption();
		examResult.getMarks();
		for(int marks=0;marks<=10;marks++)
		{
		if(userOption.getUsOption()==question.getCrctOpt())
		{
			marks++;
		}
		else {
			return marks;
		}
		}
	}*/

	

