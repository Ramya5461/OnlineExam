package com.example.demo.layer5;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.layer2.ExamResult;
import com.example.demo.layer4.ExamResultService;

import com.example.demo.layer4.exception.ResultNotFoundException;
@RestController
public class ExamResultController {
	@Autowired
	ExamResultService examResultServ;
	@PostMapping(path="/addResult")
		public void addResult(@RequestBody ExamResult result) {
		  examResultServ.addResultService(result);
		}
	 
	  @GetMapping(path="/getAllResults")
		 @ResponseBody
	     public List<ExamResult> getAllResultsService() {
		  List<ExamResult> resultList=examResultServ.getAllResultsService();	
		  return resultList;
		}
	  
	  @GetMapping(path="/getResultsByUserId/{myUserId}")
		@ResponseBody
		public 	ResponseEntity<List<ExamResult>> getResultsByUserId(@PathVariable("myUserId") int userId)throws ResultNotFoundException{
		List<ExamResult> resultList=null;
		resultList=examResultServ.getResultsByUserIdService(userId);
		if(resultList==null)
		{ return ResponseEntity.notFound().build();
		
		}
		else {
			return ResponseEntity.ok(resultList);
		}
	  }
	
		@GetMapping(path="/getResultByUserIdExamIdLevelId/{myUserId}/{myExamId}/{myLevelId}")   
		@ResponseBody
		public ResponseEntity<ExamResult> getResultByUserIdExamIdLevelId(@PathVariable("myUserId") int userId, @PathVariable("myExamId") int examId, @PathVariable("myLevelId") int levelId) throws ResultNotFoundException{
		  ExamResult examResult=null;
			examResult = examResultServ.getResultByUserIdExamIdLevelIdService(userId,examId,levelId);
			if(examResult==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(examResult);
				}
			}
}





