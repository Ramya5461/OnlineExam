package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.layer2.UserOption;
import com.example.demo.layer4.UserOptionService;

@RestController
public class UserOptionController {

	@Autowired
	UserOptionService userOptionServ;
	@PutMapping(path="/addUserOption")
	@ResponseBody
	public void addUserOption(@RequestBody UserOption userOption) {
		userOptionServ.addUserOptionService( userOption);
	}
	

	@GetMapping(path="/getUserOptionByUserIdandQuestionNumber/{userId}/{qsNo}")
	@ResponseBody
	public UserOption getUserOptionByUserIdandQuestionNumber(@PathVariable("userId") int myUserId,@PathVariable("qsNo") int myQsNo) {
		UserOption userOption=userOptionServ. getUserOptionByUserIdandQuestionNumberService( myUserId,myQsNo );
		return userOption;
	}
	
	}


