package com.example.demo.layer4;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.layer2.ExamResult;
import com.example.demo.layer4.exception.ResultNotFoundException;

@Service
public interface ExamResultService {
	void addResultService(ExamResult result);
	 List<ExamResult> getAllResultsService ();
	 ExamResult getResultByUserIdExamIdLevelIdService(int userId,int examId,int levelId) throws ResultNotFoundException;
	 List<ExamResult> getResultsByUserIdService(int userId)throws ResultNotFoundException;
	}

