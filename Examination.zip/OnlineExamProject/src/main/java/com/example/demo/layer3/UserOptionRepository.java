package com.example.demo.layer3;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.example.demo.layer2.UserOption;

@Repository
public interface UserOptionRepository {
	 void addUserOption(UserOption userOption );
	 UserOption getUserOptionByUserIdandQuestionNumber(int userId,int qsNo );
	 //List< UserOption> getUoIdByUserIdAndQuestionNumber(int userId,int qsNo);
	 //void updateUserOptionByUoId(UserOption userOption);
	 void updateUsOptionByUoId(String userOption,int userOptionId);
	
}
