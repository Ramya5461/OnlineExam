package com.example.demo.layer4.exception;

@SuppressWarnings("serial")
public class ResultNotFoundException extends Exception{
	public ResultNotFoundException(String message) {
		super(message);
	}
}


