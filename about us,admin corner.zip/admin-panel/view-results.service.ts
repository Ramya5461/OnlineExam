import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ExamResult } from './ExamResult';

@Injectable({
  providedIn: 'root'
})
export class ViewResultsService {
  
  constructor(private myHttp:HttpClient) { }
  getAllResultsService():Observable<any>{
    return this.myHttp.get<ExamResult>("http://localhost:8080/getAllResults");
  }
}

