import { TestBed } from '@angular/core/testing';

import { ViewResultsService } from './view-results.service';

describe('ViewResultsService', () => {
  let service: ViewResultsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewResultsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
