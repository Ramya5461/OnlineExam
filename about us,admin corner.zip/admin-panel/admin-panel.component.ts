import { Component, OnInit } from '@angular/core';
import { ExamResult } from './ExamResult';
import { ViewResultsService } from './view-results.service';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})
export class AdminPanelComponent implements OnInit {

  constructor(private result:ViewResultsService) { }

  ngOnInit(): void {
  }
  tempResultAry:ExamResult[]=[];

  getAllResults(){
    this.result.getAllResultsService().subscribe((data)=>{
      if(data!=null){
           this.tempResultAry=data;
           //sessionStorage.setItem("resultAllDetails",JSON.stringify(data)); // storing this on browser session
       }
       else{
           alert("unable to fetch");
       }})
     }
  }


