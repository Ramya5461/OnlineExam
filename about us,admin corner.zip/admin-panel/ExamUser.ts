export class ExamUser{
    userId!: number;
    username!: string;
    email!: string;
    mobile!: number;
    dob!: Date;
    city!: string;
    state!: string;
    qual!: string;
    yoc!: number;
   password!: string;
   resetPasswordToken!: string; 
}
