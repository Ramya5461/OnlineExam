import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor(private router:Router) { }
  
  isLoggedIn: boolean | undefined;
  loginstr!: any;
  isExamStarted!: boolean;
  ngOnInit(): void {
    alert("login status : "+this.isLoggedIn);
    this.loginstr=sessionStorage.getItem("loginInfo");
    this.isLoggedIn=JSON.parse(this.loginstr);
  }
  logInCheck(){
    this.loginstr=sessionStorage.getItem("loginInfo");
    this.isLoggedIn=JSON.parse(this.loginstr);
    alert("login status : "+this.isLoggedIn);
  }
  logOutFun(){
    if(confirm("Are you sure ?")==true){
    alert("You are logged out");
    sessionStorage.removeItem("currentUserDetails");
    this.loginstr=sessionStorage.getItem("loginInfo");
    this.isLoggedIn=JSON.parse(this.loginstr);
    this.isLoggedIn=false;
    sessionStorage.removeItem("loginInfo");
    this.router.navigate(["home"]);
    }
  }
  examStartFun(){
    this.isExamStarted=true;
  }
}
