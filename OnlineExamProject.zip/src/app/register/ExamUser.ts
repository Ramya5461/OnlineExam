export class ExamUser{
    userId: number|undefined;
   
    username: string|undefined;
   
    email: string|undefined;

   mobile: number|undefined;
    
    dob: Date|undefined;

    city: string|undefined;

    state: string|undefined;

    qual: string|undefined;

    yoc:  number|undefined;

   password: string|undefined;

   resetPasswordToken: string|undefined; 
}