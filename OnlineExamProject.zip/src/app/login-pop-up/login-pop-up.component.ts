import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-pop-up',
  templateUrl: './login-pop-up.component.html',
  styleUrls: ['./login-pop-up.component.css']
})
export class LoginPopUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
