export class UserOptionDto
{
     examId!: number;
     levelId!:number;
     userId!: number;
     questionId!: number;
     usOption!: String;
}