import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Exam } from './Exam';
import { ExamService } from './exam.service';
import { ExamInfo } from './ExamInfo';


@Component({
  selector: 'app-new-exam',
  templateUrl: './new-exam.component.html',
  styleUrls: ['./new-exam.component.css']
})
export class NewExamComponent{
  title = "Card View Demo";
  
  tempExams: Array<Exam> =[];
  ngOnInit(): void {
    this.examServ.getAllExams().subscribe((data)=>{
  
      if(data!=null){
          this.tempExams=data;
        
         // sessionStorage.setItem("ExamDetails",JSON.stringify(data)); // storing this on browser session
      }
      else{
          alert("unable to fetch");
        }})

  }
  gridColumns = 4;
  constructor(private examServ:ExamService,private router:Router) { }
  // cardData: {
  //   title: string;
  //   description: string;
  //   imageUrl: SafeResourceUrl;
  // }[] = [];
   

  // initData(): void {
  //   this.
  // cardData = [
  //   {
  //     title: "C++",
  //     description: "c++ test",
  //     imageUrl: (
  //       "/assets/img/cplus.png"
  //     )
  //   },
  //   {
  //     title: ".Net",
  //     description:
  //       ".Net exam test ",
  //     imageUrl:("/assets/img/large.png")
  //   },
  //   {
  //     title: "SQL",
  //     description: "Sql exam",
  //     imageUrl:("/assets/img/sql.png")
  //   },
  //   {
  //     title: "PHP",
  //     description:
  //       "This  is simple php exam",
  //     imageUrl:("/assets/img/php.png")
  //   },
  //   {
  //     title: "Java",
  //     description: "Level: 1",
  //     imageUrl:("/assets/img/java.png")
  //   },
  //   {
  //     title: "Python",
  //     description: "Level: 1",
  //     imageUrl:("/assets/img/java.png")
  //   },
    
  // ];
  // }

  toggleGridColumns() {
    this.gridColumns = this.gridColumns === 3 ? 4 : 3;
  }
 
  // SavingExamDetails(){
   
  //   this.examInfo.examId=501;
  //   this.examInfo.levelId=1;
  //   sessionStorage.setItem("ExamInfo",JSON.stringify("examInfo"));
  //  }


   
   getAllExams(){
    
     }
     
 
 


   tempExam: Exam= new Exam();
   examInfo: ExamInfo=new ExamInfo();
   isLoggedIn: boolean=false;
  loginstr!: any;
   getExamByName(examName: string){
    //  alert(examName); 
    this.loginstr=sessionStorage.getItem("loginInfo");
    this.isLoggedIn=JSON.parse(this.loginstr);
    if(this.isLoggedIn==true){
     this.examServ.getExamByName(examName).subscribe((data)=>{
       if (data!=null) 
       {
         this.tempExam=data;
         let levelId=0;
         let qsNo=0;
         this.examInfo.examId=this.tempExam.examId;
         this.examInfo.levelId=levelId;
         this.examInfo.qsNo=qsNo;
         this.router.navigate(["instructions"]);
         sessionStorage.setItem("examDetails",JSON.stringify(this.examInfo)); }
       else{
         alert('unable to fetch');
       }
       })
 }
 else{
   alert("Please Login...");
   this.router.navigate(["login"]);
 }
 
   }
  
}
