export class UserInfo{
    username: string | undefined;
    userId:number | undefined;
}