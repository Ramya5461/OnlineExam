package com.example.demo.layer5;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Exam;
import com.example.demo.layer2.ExamLevel;
import com.example.demo.layer2.ExamResult;
import com.example.demo.layer2.ExamUser;
import com.example.demo.layer2.DTO.ExamResultDTO;
import com.example.demo.layer4.ExamResultService;
import com.example.demo.layer4.exception.ResultNotFoundException;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ExamResultController {
	@Autowired
	ExamResultService examResultServ;
	
	 @PostMapping(path="/addResult")
		public void addResult(@RequestBody ExamResultDTO resultDto) {
		 ExamResult result=new ExamResult();
		 ExamUser user=new ExamUser();
		 Exam exam=new Exam();
		 ExamLevel level=new ExamLevel();
		 user.setUserId(resultDto.getUserId());
		 exam.setExamId(resultDto.getExamId());
		 level.setLevelId(resultDto.getLevelId());
		 result.setCrctAns(resultDto.getCrctAns());
		 result.setIncrctAns(resultDto.getIncrctAns());
		 result.setMarks(resultDto.getMarks());
		 result.setPercentage(resultDto.getPercentage());
		 result.setStatus(resultDto.getStatus());
		 result.setCrctAns(resultDto.getCrctAns());
		 result.setExamUser(user);
		 result.setExam(exam);
		 result.setExamLevel(level);
		 examResultServ.addResultService(result);
		}
	
	  @GetMapping(path="/getAllResults")
		 @ResponseBody
	     public List<ExamResult> getAllResultsService() {
		  List<ExamResult> resultList=examResultServ.getAllResultsService();	
		  return resultList;
		}
	  
	 
	  @GetMapping(path="/getResultsByUserId/{myUserId}")
			@ResponseBody
			public 	ResponseEntity<List<ExamResult>> getResultsByUserId(@PathVariable("myUserId") int userId)throws ResultNotFoundException{
			List<ExamResult> resultList=null;
			resultList=examResultServ.getResultsByUserIdService(userId);
			if(resultList==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(resultList);
			}
		  }
	  
	  @GetMapping(path="/getResultByUserIdExamIdLevelId/{myUserId}/{myExamId}/{myLevelId}")   
		@ResponseBody
		public ExamResult getResultByUserIdExamIdLevelId(@PathVariable("myUserId") int UserId, @PathVariable("myExamId") int ExamId, @PathVariable("myLevelId") int LevelId) {
		  ExamResult examResult = examResultServ.getResultByUserIdExamIdLevelIdService(UserId,ExamId,LevelId);
			return examResult;
		
		}
}



