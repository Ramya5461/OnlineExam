package com.example.demo.layer3;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.ExamUser;
import com.example.demo.layer2.UserOption;
@Repository
public class UserOptionRepositoryImpl implements UserOptionRepository {
    @PersistenceContext
    EntityManager entityManager;
   
    //To add User option to the USER_OPTION tabel
    @Transactional
    public void addUserOption(UserOption userOption) {
        entityManager.persist(userOption);
    }
    
    //Method to find User option by user id and question number
    @Transactional
    public List<UserOption> getUserOptionByUserIdandQuestionNumber(int userId, int qsId) {
        Query query=entityManager.createQuery("select u from UserOption u where user_Id=:myUserId and question_id=:myQsId",UserOption.class);
        query.setParameter("myUserId",userId);
        query.setParameter("myQsId",qsId);
         @SuppressWarnings("unchecked")
        List<UserOption> usOptionList=query.getResultList();
        return usOptionList;
    }
    
    //Method to get userOptionId from user option table using userId and question Id
    @Transactional
    public int getUoIdByUserIdAndExamId(int userId,int qsId) {
    	Query query=entityManager.createQuery("select u.userOptionId from UserOption u where user_Id=:myUserId and question_id=:myQsId",UserOption.class);
    	query.setParameter("myUserId",userId);
		query.setParameter("myQsId",qsId);
    	int Uo_id=query.getFirstResult();
    	return Uo_id;
    	
    }

	@Transactional
	public void updateUsOptionByUoId(String userOption,int userOptionId) {
		Query query=entityManager.createQuery("UPDATE from UserOption u SET u.usOption=:usOption where userOptionId=:userOptionId");
		query.setParameter("userOptionId",userOptionId);
		query.setParameter("usOption",userOption);
		query.executeUpdate();
	}

	@Override
	public ExamUser getUserByUserId(int userId) {
		// TODO Auto-generated method stub
		return null;
	}
}
