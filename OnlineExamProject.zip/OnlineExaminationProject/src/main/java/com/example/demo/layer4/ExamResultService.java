package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.ExamResult;
import com.example.demo.layer2.DTO.ExamResultDTO;
import com.example.demo.layer4.exception.ResultNotFoundException;

@Service
public interface ExamResultService {
	void addResultService(ExamResult result);
	void addResultDtoService(ExamResultDTO resultDto);
	 List<ExamResult> getAllResultsService();
	 ExamResult getResultByUserIdExamIdLevelIdService(int UserId,int ExamId,int LevelId);
	  List<ExamResult> getResultsByUserIdService(int userId) throws ResultNotFoundException;
	}

