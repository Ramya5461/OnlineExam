package com.example.demo.layer5;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.ExamUser;
import com.example.demo.layer2.Question;
import com.example.demo.layer2.UserOption;
import com.example.demo.layer2.DTO.UserOptionDto;
import com.example.demo.layer4.UserOptionService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserOptionController {
    @Autowired
    UserOptionService userOptionServ;
    
    @PutMapping(path="/addUserOption")
    @ResponseBody
    public void addUserOption(@RequestBody UserOption myUserOption) {
//    	ExamUser userObj=myUserOption.getExamUser();
//    	Question quesObj=myUserOption.getQuestion();
//    	List<UserOption> userOptionList=userOptionServ.getUserOptionByUserIdandQuestionNumberService(userObj.getUserId(),quesObj.getQsNo());
//    	for(UserOption userOpt: userOptionList) {
//    		int userOptId=userOpt.getUserOptionId();
//    		userServ.getUserOptionIdIdByUserIdAndQsNo();
//    	}
//    	if(userOptionList!=null) {
//        userOptionServ.addUserOptionService(myUserOption);
//    	}
//    	else {
//    		
//    	}
    }
    
//    @GetMapping(path="/getUserOptionByUserIdandQuestionNumber/{userId}/{qsNo}")
//    @ResponseBody
//    public UserOption getUserOptionByUserIdandQuestionNumber(@PathVariable("userId") int myUserId,@PathVariable("qsNo") int myQsNo) {
//        UserOption userOption=userOptionServ.getUserOptionByUserIdandQuestionNumberService( myUserId,myQsNo );
//        return userOption;
//    }
    
    @PostMapping(path="/updateOrAddOption")
	public void updateOrAddOption(@RequestBody UserOptionDto userOptionDtoObj) {// Controller for option add or update method
		userOptionServ.updateOrAddOptionService(userOptionDtoObj.getUserId(),userOptionDtoObj.getQuestionId(),userOptionDtoObj.getUsOption() );
	}
    
    }
