package com.example.demo.layer2.DTO;

public class UserOptionDto {
	 
	 private int userId;
	 private int questionId;
	 private String usOption;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getUsOption() {
		return usOption;
	}
	public void setUsOption(String usOption) {
		this.usOption = usOption;
	}
	
	 
	
}